// var pattern = /ka.../g;

// var text = "Kaxcsjzbcjsz is a devKaeloper"; // ['kaxcs','kaelo'] or null

// // var result = pattern.test(text);

// var result = text.match(pattern);

// console.log(result);

// var pattern = /^js*/gi;

// var text = "jas is PL  and j is SL and jssss is used in reactjsssssssssss";
// var result = text.match(pattern);

var pattern = /^jas*a*/gi; // jaa
var text = "ja78999";
var result = pattern.test(text);
console.log(result);
