// function fn() {
//   console.log("fn is called");
// }

// export default fn;

export var city = "Mumbai";

function fn() {
  console.log("fn is called");
}

export default fn;
