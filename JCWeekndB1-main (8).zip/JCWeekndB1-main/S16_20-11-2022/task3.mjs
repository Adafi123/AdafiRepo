import fn, { city } from "./task2.mjs";

fn();
console.log(city);
