function fn(...data) {
  data.forEach((ele) => {
    console.log(ele);
  });
}

fn(2, 3, 4, 5, 6, 7, 8);
