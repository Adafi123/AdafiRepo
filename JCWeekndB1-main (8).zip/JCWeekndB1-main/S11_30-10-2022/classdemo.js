class Student {
  name;
  city = "Delhi";
  email;
  id = 100;

  display() {
    "-----------";
  }

  print() {
    "----------------";
  }
  totalMarks() {
    "-----------------";
  }
}
