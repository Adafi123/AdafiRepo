import {Component} from 'react'

class MyClass extends Component {

   render(){
       return <div>
            <h2> Class Component</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis quia, tempore a deserunt similique saepe, sit ipsam eaque odit dolore esse impedit praesentium repellendus porro voluptas reprehenderit iusto omnis. Ab facere modi culpa. Eligendi eveniet tempore ipsa magni non. Voluptate, id quidem est iste voluptatem quae necessitatibus velit explicabo impedit saepe perspiciatis ut corrupti cumque, quisquam voluptatibus tenetur. Dolorum ipsa quae quasi quidem iste eligendi nam, a iusto iure, debitis eaque asperiores, reiciendis ut omnis quis reprehenderit natus distinctio cum ratione quisquam fuga dolorem dolor molestias! Dolore deleniti consequuntur quidem quae atque. Quis et itaque debitis, quaerat ipsa delectus veritatis.</p>
        </div>
   }

}

export default MyClass
