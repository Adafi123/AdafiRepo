import React from "react";

function Service(props) {
  return (
    <div>
      <h2>Service Component</h2>
    </div>
  );
}

export default Service;
