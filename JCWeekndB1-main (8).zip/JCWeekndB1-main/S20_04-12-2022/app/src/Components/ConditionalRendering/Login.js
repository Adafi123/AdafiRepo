import React from "react";

function Login(props) {
  return (
    <div>
      <h2>Login component</h2>
    </div>
  );
}

export default Login;
