import React from "react";

function UserDetails(props) {
  return (
    <div>
      <h2>User Details Component</h2>
    </div>
  );
}

export default UserDetails;
