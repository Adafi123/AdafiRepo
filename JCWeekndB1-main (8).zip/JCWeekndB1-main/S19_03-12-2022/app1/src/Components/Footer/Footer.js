import "./Footer.css";

function Footer() {
  return (
    <div className="footer">
      <h3>All Rights are Reserved by Kabir</h3>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique minus
        consequatur harum dolor perferendis sed, nulla ducimus dolore ipsum
        tempora sit voluptates expedita ipsa dolorum eveniet. Molestias neque
        consectetur blanditiis maxime perspiciatis minus vero reprehenderit id
        fuga? Debitis, cumque illo.
      </p>
    </div>
  );
}

export default Footer;
