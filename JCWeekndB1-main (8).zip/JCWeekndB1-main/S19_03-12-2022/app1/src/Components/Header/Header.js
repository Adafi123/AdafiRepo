import "./Header.css";
function Header() {
  return (
    <div className="header">
      <a className="astyle" href="">
        Home
      </a>
      <a className="astyle" href="">
        Profile
      </a>
      <a className="astyle" href="">
        Service
      </a>
      <a className="astyle" href="">
        ContactUs
      </a>
    </div>
  );
}

export default Header;
