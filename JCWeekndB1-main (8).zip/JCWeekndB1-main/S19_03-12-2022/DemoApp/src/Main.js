function Main() {
  return (
    <div>
      <ul>
        <li>React</li>
        <li>Html</li>
        <li>css</li>
        <li>JS</li>
      </ul>
    </div>
  );
}

export default Main;
