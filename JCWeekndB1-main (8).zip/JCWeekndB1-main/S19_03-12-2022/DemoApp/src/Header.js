import Main from "./Main";
function Header() {
  return (
    <div>
      <div>
        <h2>Header</h2>
        <p>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit.
          Consequuntur, pariatur?
        </p>
      </div>
      <Main> </Main>
    </div>
  );
}
export default Header;
