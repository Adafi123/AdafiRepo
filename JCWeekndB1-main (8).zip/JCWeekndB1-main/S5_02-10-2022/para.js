// function fnParameterArgument(x, y) {
//   console.log(x, y);
// }

// fnParameterArgument(200, 100);

function fnAdd(num1, num2) {
  var result = num1 + num2;
  console.log(result);
}

fnAdd(10, 20);
fnAdd(40, 30);
fnAdd(100, 600);
