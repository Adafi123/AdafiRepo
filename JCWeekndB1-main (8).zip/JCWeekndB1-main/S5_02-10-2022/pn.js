function fnPosNeg() {
  //   var positive = 100;

  //   var negativeNum = -8;

  console.log("100", "-8");
}

fnPosNeg(); //  user defined function

//  log()   ------  pre-defined
