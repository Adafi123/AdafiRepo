var id; // statement or Instructions

var name1;

var email;

id = 101;

name1 = "Kabir";

email = "Kabir@gmail.com";

console.log(email);
console.log(id);

console.log(id, email, name1);
