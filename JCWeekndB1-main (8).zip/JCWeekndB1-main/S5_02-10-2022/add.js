function add() {
  var num1 = 100;
  var num2 = 50;
  var num3 = 150;
  var result;

  result = num1 + num2 + num3;
  console.log(result);
}

function sub() {
  var num1 = 50;
  var num2 = 100;

  var r = num2 - num1;
  console.log(r);
}

add();
add();
add();
add();
add();

sub();
