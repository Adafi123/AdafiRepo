function getMarks() {
  var studentName;
  var studentEmail;

  studentName = "Chris John";
  studentEmail = "chris@gmail.com";

  console.log(studentName, studentEmail);
}

function fn() {
  console.log(
    "Welcome to Javascriptdjhdvjhavdjhavcjhvdcjhsavdjhasvdjhsavdjhsavcjhsvcsdjhcvsdjh"
  );
}

getMarks();
fn();
