// var user = []; //empty array

var user = ["Kabir", 101, true, "Sagar"];
// console.log(typeof user);
// console.log(user);

console.log(user);
user[3] = "Chris";

console.log(user[3]);
console.log(user);
