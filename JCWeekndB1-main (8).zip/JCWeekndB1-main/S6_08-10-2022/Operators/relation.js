// var a = 100;

// var b = 150;

// var c = 100;

// console.log(a > b);

// console.log(a < b);

// console.log(a >= c); // greater than or equcal to operators

// console.log(c <= b); //

// console.log(a != c); // not equcal to
// console.log(a != b); // not equcal to

var x = "101"; //string

var y = "10"; //string

console.log(x == y);
console.log(x === y);
