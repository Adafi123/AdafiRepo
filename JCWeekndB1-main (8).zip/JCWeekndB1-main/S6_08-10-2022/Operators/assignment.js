// var a = 55;
// var b;

// b = a;
// console.log(b, a);

// var a = 10;
// var b = 20;

// // a += b; // a =a+b
// // console.log(a, b); //  a = 30 and b=20

// console.log("-----------------------------");

// b += a; // b= b+a
// console.log(a, b); // a = 10 b =30

// var x = 20;
// var y = 100;

// // x *= y; //  x =x*y
// // console.log(x, y); //x = 2000   y =100

// y *= x;
// console.log(x, y); // x= 20  y=2000
