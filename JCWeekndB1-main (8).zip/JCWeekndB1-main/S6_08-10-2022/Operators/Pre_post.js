// var num1 = 300; // 1 + 300  or  300 + 1
// post incremeent
// num1++; //301
// num1++; //302
// num1++; //303

//post decrement
// num1--; //299
// num1--; //298
// num1--; //297

//pre-increment
// ++num1; //301
// ++num1; //302

// //pre-decrement
// --num1; // 299
// --num1; // 298
// console.log(num1);

var x = 10;

console.log(x++);
console.log(x);

// pre inc or dec
// inc or dec then it prints value

//post in or dec
// first its prints value then it will increase
