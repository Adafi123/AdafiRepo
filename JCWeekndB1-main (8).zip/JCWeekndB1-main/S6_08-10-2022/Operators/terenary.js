var a = 70;

a > 50 //true
  ? console.log("a is greater than 50")
  : console.log("a is smaller than 50");
