var name = "ckdsjbcjdsnc";

console.log(typeof name);
