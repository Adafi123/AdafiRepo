var obj = {
  id: 101,
  name: "Chris",
  gender: "male",
  email: "Chris@gmail.com",
};

var obj1 = {
  id: 102,
  name: "John",
  gender: "male",
  email: "John@gmail.com",
};

console.log(obj, obj1);
