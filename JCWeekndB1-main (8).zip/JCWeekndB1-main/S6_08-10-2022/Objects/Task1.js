var productDetails = {
  productName: "Iphone 14",
  productCategory: "electronics",
  productPrice: 3000,
};
console.log(productDetails);

var empDetails = {
  empName: "Kabir",
  empNo: 10001,
  empSalary: 75000,
};
console.log(empDetails);
