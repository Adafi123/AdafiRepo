function returnString(name) {
  console.log("welcome");
  console.log(name);
  return name + "Sagar";
}

var result = returnString("Kabir");
console.log(result);
