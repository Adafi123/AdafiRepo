function fnAdd(num1, num2) {
  var x;
  var y;

  x = num1;
  y = num2;

  console.log(x + y);
}

fnAdd(10, 20);

fnAdd(100, 200);

fnAdd(1000, 2000);
