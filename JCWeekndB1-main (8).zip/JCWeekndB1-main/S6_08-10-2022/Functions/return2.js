function fnMul(fnAddValue, num3) {
  console.log(fnAddValue * num3);
}

function fnAdd(num1, num2) {
  //   var result = num1 + num2;
  //return result

  return num1 + num2;
}

var resultOfF1 = fnAdd(10, 10); //20

fnMul(resultOfF1, 100); //2000
