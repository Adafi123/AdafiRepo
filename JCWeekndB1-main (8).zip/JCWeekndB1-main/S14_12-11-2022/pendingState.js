function createPromise() {
  var promise = new Promise(function (resolve, reject) {});

  console.log(promise);
}

createPromise();
