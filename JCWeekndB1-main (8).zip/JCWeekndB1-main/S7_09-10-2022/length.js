var users = ["Ahana", "Chris", "John", "Smith", "Robin", "Seema", "Alina"];

var employess = [];

console.log(users.length);

console.log(employess.length);
