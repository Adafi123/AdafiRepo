function printEvenOrOdd(num) {
  if (num % 2 === 0) {
    console.log(num, "is a even number");
  } else {
    console.log(num, "is a odd number ");
  }
}

printEvenOrOdd(12); // 10 is a even number

printEvenOrOdd(8); // 9 is a odd number
