function fn() {
  var a = 700;

  if (a > 500) {
    console.log("a is greater then 500");
  }
}

fn();
