var arr = [10, 20, 30];

var newArray = arr.map(function (ele) {
  return ele + 10;
});

console.log(newArray);
