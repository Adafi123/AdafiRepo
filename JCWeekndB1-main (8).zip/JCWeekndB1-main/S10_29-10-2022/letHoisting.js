console.log(id);

const id = 101; //error
