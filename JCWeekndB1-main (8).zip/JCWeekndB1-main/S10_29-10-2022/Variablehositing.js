// var email; // data or values

// console.log(email);

//  What is undefined ?
//  undefined is special value or special data in javascript

// Variable Hoisting

console.log(city); //undefined

var city = "Delhi";
console.log(city);
