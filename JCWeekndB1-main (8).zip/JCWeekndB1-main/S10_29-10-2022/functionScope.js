var id = 101;

function fn() {
  var email = "Kabir@gmail.com";
  function f1() {
    console.log("f1 is called");
  }

  f1();
}

console.log(email);
f1();
