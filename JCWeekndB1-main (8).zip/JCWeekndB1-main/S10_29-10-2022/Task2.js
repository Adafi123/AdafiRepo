var a;
var b;
var c;
var d;

console.log(b); //undefined

b = 10;

c;

d = 20;
