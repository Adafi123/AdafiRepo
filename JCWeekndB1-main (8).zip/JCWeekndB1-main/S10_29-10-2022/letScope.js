let a = "dskjncdjksn";
const p = 101;

function f1() {
  let city = "Delhi";

  if (false) {
    const z = 100;
    let id = 101;
    console.log(city, id);
  } else {
    let x = 100;
    var y = 300;
  }
  //   console.log(id);
  console.log(y);
  console.log(z);
}
f1();
