fn();

function fn() {
  console.log("fn is called");
}
