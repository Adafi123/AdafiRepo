// let regex = /Kab*i*r*/gi;

// let text =
//   "Hello I am kabbiiirrrr and kabir is a Developer and Kabir is a Trainer";

// // var result = regex.test(text);

// var result = text.match(regex);

// console.log(result);

var pattern = /^k*a?b?i?r?/;

var text = "aaaaaaaaaaaaaaaRaj is a developer";

var result = pattern.test(text);

console.log(result);
