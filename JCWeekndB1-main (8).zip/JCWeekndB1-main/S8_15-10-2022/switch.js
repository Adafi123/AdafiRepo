var a = 6;

switch (
  a - 1 //0
) {
  case 1:
    console.log("1");
    break;
  case 5:
    console.log("5");
    break;
  case 6:
    console.log("6");
    break;
  case 10:
    console.log("10");
    break;
  default:
    console.log("No case got matched");
}
