function fnwhile() {
  var i = 11;

  while (i <= 10) {
    console.log(i);
    i++;
  }
}

fnwhile();
