var arr = [10, 20, 30, 40, 50];

for (var ele of arr) {
  console.log(ele);
}
